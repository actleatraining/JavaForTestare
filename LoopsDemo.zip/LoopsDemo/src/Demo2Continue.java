public class Demo2Continue {
    public static void main(String[] args) {

        for (int i = 0; i < 5; i++) {
            if (i == 3) {
                continue;
            }
            System.out.println("Index: " + i);
        }

        System.out.println();

        // Alternative solution with if instead of continue
        for (int i = 0; i < 5; i++) {
            if (i != 3) {
                System.out.println("Index: " + i);
            }
        }
    }
}