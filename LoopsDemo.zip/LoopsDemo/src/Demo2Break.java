import java.util.Scanner;

public class Demo2Break {
    public static void main(String[] args) {

        System.out.println("What is 3 + 4?");
        Scanner scanner = new Scanner(System.in);
        int answer;

        while (true) {
            answer = scanner.nextInt();
            if (answer == 7) {
                break; // breakes out of the infinite loop
            }
            System.out.println("Sorry, wrong answer, try again!");
        }

        System.out.println("Correct answer!");
    }
}