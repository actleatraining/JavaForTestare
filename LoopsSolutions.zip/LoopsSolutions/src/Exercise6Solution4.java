public class Exercise6Solution4 {
    public static void main(String[] args) {

        int number = 5;

        for (int i = 0; i < number; i++) {
            for (int j = 0; j < number; j++) {
                if (i % 2 == 0) {
                    if (j % 2 == 0) {
                        System.out.print("X ");
                    }
                    else {
                        System.out.print("O ");
                    }                }
                else {
                    if (j % 2 == 0) {
                        System.out.print("O ");
                    }
                    else {
                        System.out.print("X ");
                    }                }
            }
            System.out.println();
        }
    }
}