public class Exercise3SolutionFor {
    public static void main(String[] args) {

        System.out.print("Task 1: ");
        for (int i = 1; i < 6; i++) {
            System.out.print(i + " ");
        }

        System.out.println();
        System.out.print("Task 2: ");
        for (int i = 8; i < 13; i++) {
            System.out.print(i + " ");
        }

        System.out.println();
        System.out.print("Task 3: ");
        for (int i = 12; i > 7; i--) {
            System.out.print(i + " ");
        }

        System.out.println();
        System.out.print("Task 4: ");
        for (int i = 10; i < 51; i+=10) {
            System.out.print(i + " ");
        }
    }
}