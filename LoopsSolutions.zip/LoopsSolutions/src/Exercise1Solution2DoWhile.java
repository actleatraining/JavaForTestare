import java.util.Scanner;

public class Exercise1Solution2DoWhile {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Please enter the first number: ");
        int number1 = scanner.nextInt();

        System.out.print("Please enter the second number: ");
        int number2 = scanner.nextInt();

        String operator = "";

        do {
            System.out.print("Please enter a valid operator (+ - * /): ");
            operator = scanner.next();
        }
        while(!operator.equals("+") && !operator.equals("-") && !operator.equals("*") && !operator.equals("/"));

        int result = 0;

        // Switch statement
        switch (operator) {
            case "+":
                result = number1 + number2;
                break;
            case "-":
                result = number1 - number2;
                break;
            case "*":
                result = number1 * number2;
                break;
            case "/":
                result = number1 / number2;
                break;
        }

        System.out.println("Result = " + result);
    }
}
