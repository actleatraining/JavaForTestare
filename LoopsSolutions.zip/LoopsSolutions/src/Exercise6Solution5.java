public class Exercise6Solution5 {
    public static void main(String[] args) {

        int number = 5;

        for (int y = 1; y <= number; y++) {
            for (int n = 1; n <= y; n++) {
                System.out.print(n);
            }

            for (int s = y; s < number; s++) {
                System.out.print('*');
            }

            System.out.println();
        }
    }
}