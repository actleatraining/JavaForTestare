public class Exercise6Solution3Task2 {
    public static void main(String[] args) {

        int number = 5;

        for (int i = 0; i < number; i++) {
            for (int j = 0; j < number; j++) {
                if (j % 2 == 0) {
                    System.out.print("X ");
                }
                else {
                    System.out.print("O ");
                }
            }
            System.out.println();
        }
    }
}