import java.util.Scanner;

public class Exercise2Solution {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String answer = "";

        do {
            System.out.print("Please enter the first number: ");
            int number1 = scanner.nextInt();

            System.out.print("Please enter the second number: ");
            int number2 = scanner.nextInt();

            System.out.print("Please enter the operator (+ - * /): ");
            String operator = scanner.next();

            while(!operator.equals("+") && !operator.equals("-") && !operator.equals("*") && !operator.equals("/")) {
                System.out.println("Invalid operator");
                System.out.print("Please enter the operator (+ - * /): ");
                operator = scanner.next();
            }

            int result = 0;

            // Switch statement
            switch (operator) {
                case "+":
                    result = number1 + number2;
                    break;
                case "-":
                    result = number1 - number2;
                    break;
                case "*":
                    result = number1 * number2;
                    break;
                case "/":
                    result = number1 / number2;
                    break;
            }

            System.out.println("Result = " + result);

            System.out.println("Do you want to do another calculation? Enter y for yes or n for no");
            answer = scanner.next();
        }
        while (answer.equals("y"));

    }
}
