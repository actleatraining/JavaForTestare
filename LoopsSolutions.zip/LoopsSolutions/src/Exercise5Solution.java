import java.util.Scanner;

public class Exercise5Solution {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String answer = "";

        while(true) {
            System.out.print("Please enter the first number: ");
            int number1 = scanner.nextInt();

            System.out.print("Please enter the second number: ");
            int number2 = scanner.nextInt();

            String operator = "";
            while(true) {
                System.out.print("Please enter a valid operator (+ - * /): ");
                operator = scanner.next();
                if (operator.equals("+") || operator.equals("-") || operator.equals("*") || operator.equals("/")) {
                    break;
                }
            }

            int result = 0;

            // Switch statement
            switch (operator) {
                case "+":
                    result = number1 + number2;
                    break;
                case "-":
                    result = number1 - number2;
                    break;
                case "*":
                    result = number1 * number2;
                    break;
                case "/":
                    result = number1 / number2;
                    break;
            }

            System.out.println("Result = " + result);

            System.out.println("Do you want to do another calculation? Enter y for yes or n for no");
            answer = scanner.next();
            if (!answer.equals("y")) {
                break;
            }
        }
    }
}
