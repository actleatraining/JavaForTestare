public class ArraysSolution2 {

    public static void main(String[] args) {
        int[] numbers = {56,13,84,7,11,21,79};

        // Lowest number
        int lowestSoFar = numbers[0];
        for (int i = 1; i < numbers.length; ++i) {
            int current = numbers[i];
            if (current < lowestSoFar) {
                lowestSoFar = current;
            }
        }
        System.out.println("Lowest number: " + lowestSoFar);

        // Highest number
        int highestSoFar = numbers[0];
        for (int i = 1; i < numbers.length; ++i) {
            int current = numbers[i];
            if (current > highestSoFar) {
                highestSoFar = current;
            }
        }
        System.out.println("Highest number: " + highestSoFar);

        // Sum of the numbers
        int sum = 0;
        for (int i = 0; i < numbers.length; ++i) {
            double current = numbers[i];
            sum += current;
        }
        System.out.println("Sum of numbers: " + sum);

        // Average of the numbers
        double average = sum / numbers.length;
        System.out.println("Average of numbers: " + average);
    }
}
