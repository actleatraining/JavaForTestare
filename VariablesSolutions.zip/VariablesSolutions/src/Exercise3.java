public class Exercise3 {
    public static void main(String[] args) {
        // 1
        final int CONSTANT_1;
        CONSTANT_1 = 2;

        // 2 NOT VALID! final should be put before the type
        // int final CONSTANT_2;

        // 3
        final int TEST_3 = 3;

        // 4 NOT VALID! This is exaclty what the final keyword prevents, that is to change the value of the variable
        final int TEST_4 = 4;
        //TEST_4 = 0;
    }
}