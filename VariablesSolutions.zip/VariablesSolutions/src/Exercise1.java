public class Exercise1 {
    public static void main(String[] args) {
        int diameter = 100;
        double pi = 3.14;

        // Solution 1 by changing the type of circumerence to double
        double circumference = diameter * pi;
        System.out.println("Solution 1: " + circumference);

        // Solution 2 by casting pi to int (the result will be 300)
        int circumference2 = diameter * (int)pi;
        System.out.println("Solution 2: " + circumference2);

        // Solution 3 by casting the entire result of the calculation to int (the result will be 314)
        int circumference3 = (int)(diameter * pi);
        System.out.println("Solution 3: " + circumference3);
    }
}