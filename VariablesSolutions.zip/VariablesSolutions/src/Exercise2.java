public class Exercise2 {
    public static void main(String[] args) {

        // Solution 1 using float
        float amount = 0;
        amount += 0.1f;
        amount += 0.1f;
        amount += 0.1f;
        amount += 0.1f;
        amount += 0.1f;
        amount += 0.1f;
        amount += 0.1f;
        amount += 0.1f;
        amount += 0.1f;
        amount += 0.1f;
        System.out.println("Solution 1 using float: " + amount);

        // Solution 2 using float
        double amount2 = 0;
        amount2 += 0.1f;
        amount2 += 0.1f;
        amount2 += 0.1f;
        amount2 += 0.1f;
        amount2 += 0.1f;
        amount2 += 0.1f;
        amount2 += 0.1f;
        amount2 += 0.1f;
        amount2 += 0.1f;
        amount2 += 0.1f;
        System.out.println("Solution 2 using double: " + amount2);
    }
}