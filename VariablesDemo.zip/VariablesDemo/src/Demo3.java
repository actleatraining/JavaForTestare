public class Demo3 {
    public static void main(String[] args) {

        byte a = 1;
        int b = 4;
        double c = 2.7;

        // Implicit type conversion
        int test1 = a;
        double test2 = a;
        double test3 = b;

        // Explicit type conversion
        byte test4 = (byte)(b);
        byte test5 = (byte)c; // will lose precision, the decimals will be cut off!
        int test6 = (int)c; // will lose precision, the decimals will be cut off!

        System.out.println(test4);
        System.out.println(test5);
        System.out.println(test6);

        // Arithmetic operators and type conversion
        //byte test7 = a + (byte)b; // can't cast only the int when dealing with byte
        byte test8 = (byte)(a + b); // must cast the result when dealing with byte
        int test9 = b + (int)c; // when dealing with int it is ok to only cast the double (but will lose precision!)

        System.out.println(test8);
        System.out.println(test9);
    }
}