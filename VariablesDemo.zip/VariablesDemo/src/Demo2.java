public class Demo2 {
    public static void main(String[] args) {

        // Declaring primitive types
        byte b;
        short s;
        int number;
        long key;
        float pi;
        double highPrecisionPi;
        boolean isEnabled;
        char character;

        // Declaring and initializing primitive types
        byte b2 = 4;
        short s2 = 56;
        int number2 = 27;
        long key2 = 445;
        float pi2 = 3.14f;
        double highPrecisionPi2 = 3.14;
        boolean isEnabled2 = true;
        char character2 = 'A';

        // Declaring a constant
        final int constant = 5; // declaring and assigning a value is ok!
        //constant = 7; // but changing it is not ok!

        final int constant2; // declaring without assigning a value is ok!
        constant2 = 5; // assigning a value once is ok!
        //constant2 = 7; // but changing it is not ok!
    }
}