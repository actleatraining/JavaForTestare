public class Demo1 {
    public static void main(String[] args) {

        // Declaring variables
        int number;
        float pi;
        boolean isEnabled;
        char character;

        // Initializing variables (assigning values to variables)
        number = 27;
        pi = 3.14f;
        isEnabled = true;
        character = 'A';

        // Declaring and initializing at the same time
        int number2 = 27;
        float pi2 = 3.14f;
        boolean isEnabled2 = true;
        char character2 = 'A';
    }
}