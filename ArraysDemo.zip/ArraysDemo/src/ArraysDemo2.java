import java.util.Arrays;

public class ArraysDemo2 {

    public static void main(String[] args) {
        int[] numbers3 = {5,3,8,6,1};

        // getting the size of the array - called the length
        int length = numbers3.length;

        // get the last element with index length-1
        System.out.println(numbers3[numbers3.length-1]);

        System.out.println(numbers3); // will not print out the elements

        System.out.println(Arrays.toString(numbers3)); // Arrays.toString helper method for printing out arrays

        Arrays.sort(numbers3);
        System.out.println(Arrays.toString(numbers3)); // Arrays.sort sorts the array!

        int[] numbers2 = new int[5];
        Arrays.fill(numbers2, 9); // Arrays.fill fills array with an element
        System.out.println(Arrays.toString(numbers2));
    }
}
