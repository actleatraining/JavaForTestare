import java.util.Arrays;

public class ArraysDemo1 {

    public static void main(String[] args) {

        // separate int variables can be used to hold multiple int values
        int number1 = 5;
        int number2 = 3;
        int number3 = 8;

        // one int array can be used to hold the same multiple values

        // declaring an int array variable using brackets []
        int[] numbers;

        // initializing the array by assigning a new int array to the variable
        // the size must be specified and can never change (but you could assign a new array with another size to the same variable)
        numbers = new int[3];

        // could of course create and assign on one line
        int[] numbers2 = new int[10];

        // creating, assigning and initializing the elements
        int[] numbers3 = {5,3,8,6,1}; // the size is inferred from the number of elements

        // assigning values to separate elements in the array
        numbers[0] = 5;
        numbers[1] = 3;
        numbers[2] = 8;

        // get the first element with index 0 (the index is zero based)
        System.out.println(numbers[0]);
    }
}
