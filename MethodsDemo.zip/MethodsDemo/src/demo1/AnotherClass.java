package demo1;

public class AnotherClass {

    public static void publicMethod() {
        System.out.println("I'm public!");
    }

    private static void privateMethod() {
        System.out.println("I'm private!");
    }
}
