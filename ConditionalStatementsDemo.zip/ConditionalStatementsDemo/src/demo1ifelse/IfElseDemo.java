package demo1ifelse;

public class IfElseDemo {

    public static void main(String[] args) {

        int number = 2;

        // if-else
        if (number == 10) {
            System.out.println("The number is ten");
        }
        else if (number == 20) {
            System.out.println("The number is twenty");
        }
        else if (number % 3 == 3) {
            System.out.println("The number is evenly divisible by three!");
        }
        else {
            System.out.println("The number is " + number);
        }
    }
}
