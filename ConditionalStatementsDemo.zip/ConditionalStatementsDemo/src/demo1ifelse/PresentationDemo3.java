package demo1ifelse;

public class PresentationDemo3 {

    public static void main(String[] args) {

        boolean condition1 = true;
        boolean condition2 = true;

        if (condition1) {
            System.out.println("condition1 is true");
        }
        else if (condition2) {
            System.out.println("condition1 is false and condition2 is true");
        }
        else {
            System.out.println("both conditions are false");
        }
    }
}
