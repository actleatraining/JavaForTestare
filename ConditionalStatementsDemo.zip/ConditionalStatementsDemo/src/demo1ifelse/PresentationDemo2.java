package demo1ifelse;

public class PresentationDemo2 {

    public static void main(String[] args) {

        boolean condition1 = true;

        if (condition1) {
            System.out.println("The condition is true!");
        }
        else {
            System.out.println("The condition is false!");
        }
    }
}
