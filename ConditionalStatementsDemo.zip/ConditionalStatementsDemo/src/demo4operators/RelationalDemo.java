package demo4operators;

public class RelationalDemo {

    public static void main(String[] args) {

        int number = 2;

        // if-else
        if (number < 10) {
            System.out.println("The number is less than ten");
        }
        else if (number <= 15) {
            System.out.println("The number is greater than nine and less than 16");
        }
        else if (number >= 20) {
            System.out.println("The number is greater than 19");
        }
        else {
            System.out.println("The number is greater than 15 and less than 20");
        }
    }
}
