package demo4operators;

public class LogicalDemo {

    public static void main(String[] args) {

        String password = "12";

        // Example 1 - Alternative 1
        if (password.equals("admin") || password.equals("123")) {
            System.out.println("'admin' or '123' is not a great password!");
        }
        else {
            System.out.println("Great password! (not 'admin' or '123')");
        }

        // Example 1 - Alternative 2
        if (!password.equals("admin") && !password.equals("123")) {
            System.out.println("Great password! (not 'admin' or '123')");
        }
        else {
            System.out.println("'admin' or '123' is not a great password!");
        }



        // Example 2 - Alternative 1
        if (password.length() < 3 || password.length() > 12) {
            System.out.println("Incorrect format! The minimum length is 3 and the maximum length is 12");
        }
        else {
            System.out.println("Great password! (not less than 3 or greater than 12 characters");
        }

        // Example 2 - Alternative 2
        if (password.length() >= 3 && password.length() <= 12) {
            System.out.println("Great password! (not less than 3 or greater than 12 characters");
        }
        else {
            System.out.println("Incorrect format! The minimum length is 3 and the maximum length is 12");
        }



        if (true && true && false && true) {
            System.out.println("Only three statements will be evaluated");
        }

        if (true || false || true) {
            System.out.println("Only two statements will be evaluated");
        }
    }
}
