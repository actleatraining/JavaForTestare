package demo3ternary;

public class PresentationDemo1 {

    public static void main(String[] args) {

        String variable = "";
        boolean condition = true;
        String expressionIfTrue = "condition is true";
        String expressionIfFalse = "condition is false";

        // Like in the presentation
        variable = (condition) ? expressionIfTrue : expressionIfFalse;

        // The values in expressions doesn't need to be variables
        variable = (condition) ? "condition is true" :  "condition is false";

        System.out.println(variable);

        // The ternary expression returns one of the alternatives directly to the println method
        System.out.println((condition) ? "condition is true" :  "condition is false");
    }
}
