package demo3ternary;

public class TernaryDemo {

    public static void main(String[] args) {

        boolean isTuesday = true;

        // If/else
        if (isTuesday) {
            System.out.println("Tuesday!");
        }
        else {
            System.out.println("Anyting but Tuesday!");
        }

        // Ternary expression
        System.out.println(isTuesday ? "Tuesday!" : "Anyting but Tuesday!");

    }
}
