package demo2switchstatement;

public class SwitchCaseDemo2 {

    public static void main(String[] args) {

        int number = 43;

        String message = null;

        // switch-case
        switch (number) {
            case 1:
                //System.out.println("The number is one!");
                message = "The number is one!";
                break;
            case 2:
                //System.out.println("The number is two!");
                message = "The number is two!";
                break;
            case 3:
            case 4:
                //System.out.println("The number is three or four!");
                message = "The number is three or four!";
                break;
            default:
                //System.out.println("The number is neither 1,2,3 or 4, it's actually: " + number);
                message = "The number is neither 1,2,3 or 4, it's actually: " + number;
        }

        System.out.println(message);
    }
}
