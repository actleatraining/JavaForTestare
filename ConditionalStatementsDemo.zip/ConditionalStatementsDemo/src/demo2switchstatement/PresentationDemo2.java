package demo2switchstatement;

public class PresentationDemo2 {

    public static void main(String[] args) {

        String expression = "x";

        switch (expression) {
            case "x":
                System.out.println("The value of expression is x");
                break;
            case "y":
                System.out.println("The value of expression is y");
                break;
            default:
                System.out.println("The value of expression is neither x or y");
        }
    }
}
